# AiRez MVP Code - mock mode still ON
print('Hello AiRez')